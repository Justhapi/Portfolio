"use client";

import { useCallback, useEffect, useState } from "react";
import type { CSSProperties } from "react";
import Sparkle from "./SparkleText";

/**
 * SparkleField — continuously-respawning scatter of cycling-glyph sparkles.
 *
 * Each "slot" fades in, twinkles for its lifespan, then fades out and respawns
 * at a new random position with a new variant. Each slot manages its own timer
 * in a child component so a respawn in one slot never resets the others.
 *
 * Props:
 *   count      — number of simultaneous sparkles (default 14)
 *   scale      — visual size multiplier applied via font-size (default 1)
 *   slowdown   — glyph cycle speed multiplier: >1 = slower cycle (default 1)
 *   lifeScale  — life duration multiplier: >1 = longer-lived sparkles (default 1)
 *
 * Usage — hero (energetic, tight):   <SparkleField count={14} />
 * Usage — connect (slow, spacious):  <SparkleField count={10} scale={1.5} slowdown={2} lifeScale={1.4} />
 */

type Variant = "gem" | "mini" | "splatter";

type SlotData = {
  id: number;
  x: number; // %
  y: number; // %
  variant: Variant;
  duration: number; // glyph cycle period (s)
  life: number; // ms the slot lives before respawning
  scale: number; // visual size multiplier
  /** Delay before the slot's starLife entrance begins (ms). Non-zero
   *  on FIRST mount so slots blink in independently instead of appearing
   *  as a single fade. Zero on subsequent respawns — those already
   *  have organic timing from the previous slot's life ending. */
  spawnDelay: number;
};

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function freshFields(slowdown = 1, lifeScale = 1, scale = 1): Omit<SlotData, "id" | "spawnDelay"> {
  /* Variant selection:
       ~12.5%  splatter — rare hand-drawn ink blob for texture accent
       ~40%    mini     — soft dot cycle
       ~47.5%  gem      — the standard ✦ ✧ sparkle
     Splatter is intentionally rare so it reads as an accidental
     ink-fleck rather than a repeating decorative element. */
  const roll = Math.random();
  let variant: Variant;
  if (roll < 0.125) variant = "splatter";
  else if (roll < 0.525) variant = "mini";
  else variant = "gem";

  return {
    x: rand(3, 97),
    y: rand(3, 97),
    variant,
    duration: rand(0.45, 0.75) * slowdown,
    // each star lives 10–20 s (× lifeScale) before fading out and respawning elsewhere
    life: rand(10000, 20000) * lifeScale,
    scale,
  };
}

/** One star: owns its own respawn timer so it's isolated from sibling re-renders. */
function StarSlot({
  data,
  generation,
  onExpire,
}: {
  data: SlotData;
  generation: number; // bumps every respawn → effect re-runs with fresh timer
  onExpire: (id: number) => void;
}) {
  useEffect(() => {
    // Expire timer includes the spawnDelay so a slot with a large initial
    // delay (say 4200ms) still gets its full `life` visible on-screen
    // before it fades out and respawns.
    const t = window.setTimeout(() => onExpire(data.id), data.life + data.spawnDelay);
    return () => window.clearTimeout(t);
    // re-run only when THIS slot respawns (generation bump) or unmounts
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [generation]);

  const style: CSSProperties & Record<string, string> = {
    left: `${data.x}%`,
    top: `${data.y}%`,
    "--star-life": `${data.life}ms`,
    // per-slot entrance stagger so the field blinks in independently
    // instead of arriving as one synchronized fade
    "--star-delay": `${data.spawnDelay}ms`,
    // scale via font-size so the glyph and any border/padding scale together
    fontSize: `${data.scale}em`,
  };

  return (
    <span className="hero-spark star-slot" style={style}>
      <Sparkle variant={data.variant} duration={data.duration} />
    </span>
  );
}

export default function SparkleField({
  count = 14,
  scale = 1,
  slowdown = 1,
  lifeScale = 1,
}: {
  count?: number;
  scale?: number;
  slowdown?: number;
  lifeScale?: number;
}) {
  // Map<id, { data, generation }> — generation bumps to force StarSlot remount on respawn.
  const [slots, setSlots] = useState<Array<SlotData & { gen: number }>>([]);

  // Populate client-side to avoid Math.random hydration mismatch.
  // Initial slots get staggered spawn delays so the field blinks in
  // over ~1.6s instead of arriving as one synchronized fade — but the
  // FIRST slot starts at delay 0 so the viewer sees sparkles from the
  // moment the page loads. Previously deferred to 3300ms; the sparkles
  // are lightweight enough visually (12–20px, low-opacity) that they
  // don't compete with the hero entrance choreography at t=0.
  useEffect(() => {
    setSlots(
      Array.from({ length: count }, (_, i) => ({
        id: i,
        gen: 0,
        spawnDelay: i * 180 + Math.random() * 400,
        ...freshFields(slowdown, lifeScale, scale),
      })),
    );
  }, [count, slowdown, lifeScale, scale]);

  const handleExpire = useCallback(
    (id: number) => {
      setSlots((prev) =>
        prev.map((s) =>
          // Respawn: no additional delay — the previous slot's life already
          // ended organically, and adding a delay would leave a visible gap.
          s.id === id ? { id, gen: s.gen + 1, spawnDelay: 0, ...freshFields(slowdown, lifeScale, scale) } : s,
        ),
      );
    },
    [slowdown, lifeScale, scale],
  );

  if (slots.length === 0) return null;

  return (
    <>
      {slots.map((s) => (
        // The `key` change on respawn forces React to unmount the previous
        // element + mount a fresh one — restarting the CSS lifecycle.
        <StarSlot
          key={`${s.id}-${s.gen}`}
          data={s}
          generation={s.gen}
          onExpire={handleExpire}
        />
      ))}
    </>
  );
}
