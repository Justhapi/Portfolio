"use client";

import { useMemo, useState, useEffect } from "react";

/**
 * Artist · Designer wordmark — letters drop in from above one at a time.
 *
 * Ported from /next-site/wordmark.jsx + main.jsx (the latest drop-down
 * prototype) into a single self-contained component for the Next.js site.
 *
 * When the "i" in Artist bounces on impact, its dot is knocked loose, arcs
 * up and over, and lands inside the 4-point star between Artist and Designer
 * — the star bursts open at the moment the dot arrives. A second dot is
 * then ejected from the burst star and settles as the middot punctuation
 * between Artist and Designer. A replacement dot also pops back onto the i.
 *
 * Visual order (sequence the letters fall):
 *   A → r → t → i (body + dot, dot flies off on bounce) → s
 *     → [dot lands → star bursts → second dot ejects] → D → e → s → i → g → n → e → r
 */

type Glyph = { id: string; dur: number; d: string };

// Each glyph gets a `dur` multiplier so the drop pace varies per letter,
// giving the cascade a more natural, hand-tossed feel.
const GLYPHS: Glyph[] = [
  // Artist
  { id: "A", dur: 1.05, d: "M4.31586 132.649C2.41774 132.091 1.13372 131.309 0.463794 130.304C-0.206131 129.188 -0.150304 127.457 0.631275 125.112L35.2999 19.9341C36.1931 17.1427 37.2538 15.1888 38.482 14.0722C39.7102 12.9557 41.6642 12.3974 44.3439 12.3974H61.9294C64.6091 12.3974 66.5631 12.9557 67.7913 14.0722C69.0195 15.1888 70.0802 17.1427 70.9734 19.9341L105.642 125.112C106.424 127.457 106.479 129.188 105.81 130.304C105.14 131.309 103.856 132.091 101.957 132.649L86.2142 137.003C82.9762 137.897 80.799 136.613 79.6824 133.151C79.6824 133.151 78.1765 119.796 73.4856 113.054C70 108.044 35.5 108.544 32.6202 113.054C28.2099 119.96 26.5909 133.151 26.5909 133.151C25.4743 136.613 23.2971 137.897 20.0591 137.003L4.31586 132.649ZM53.0529 45.8937C53.0529 45.8937 34.2676 87.5965 40.3243 87.5965C49.5 87.5965 57 87.5965 65.7815 87.5965C72.0401 87.5965 53.0529 45.8937 53.0529 45.8937Z" },
  { id: "r", dur: 0.95, d: "M119.658 54.4352C119.658 52.7604 119.714 51.4205 119.826 50.4157C119.937 49.2991 120.216 48.4617 120.663 47.9035C121.221 47.3452 121.947 46.8986 122.84 46.5636C123.733 46.2286 124.906 45.9495 126.357 45.7262C130.489 45.1679 135.122 44.6655 140.258 44.2188C145.506 43.7722 150.698 43.4931 155.834 43.3814C160.97 43.1581 165.771 43.0465 170.237 43.0465C174.815 43.0465 178.444 43.214 181.124 43.5489C183.022 43.7722 184.194 44.1631 184.641 44.7213C185.087 45.1679 185.255 46.3403 185.143 48.2384L184.641 57.6174C184.529 59.9621 184.194 61.4136 183.636 61.9719C183.078 62.4185 181.57 62.586 179.114 62.4743C177.439 62.4743 174.983 62.5301 171.745 62.6418C168.507 62.7534 165.046 62.9209 161.361 63.1442C157.788 63.2559 154.215 63.4792 150.642 63.8142C147.069 64.0375 144.11 64.3166 141.766 64.6516L142.101 132.984C142.101 134.77 141.766 135.999 141.096 136.669C140.426 137.338 139.142 137.673 137.244 137.673H125.855C123.957 137.673 122.673 137.338 122.003 136.669C121.333 135.999 120.998 134.77 120.998 132.984L119.658 54.4352Z" },
  { id: "t", dur: 1.0, d: "M199.933 65.154C198.146 65.154 196.918 64.8749 196.248 64.3166C195.578 63.7584 195.243 62.586 195.243 60.7995V50.2482C195.243 48.4617 195.578 47.2894 196.248 46.7311C196.918 46.0612 198.146 45.7262 199.933 45.7262H216.011V14.9096C216.011 13.1232 216.346 11.895 217.016 11.2251C217.686 10.5551 218.97 10.2202 220.868 10.2202H232.257C234.155 10.2202 235.439 10.5551 236.109 11.2251C236.779 11.895 237.113 13.1232 237.113 14.9096V45.7262H260.393C262.18 45.7262 263.408 46.0612 264.078 46.7311C264.748 47.2894 265.083 48.4617 265.083 50.2482V60.7995C265.083 62.586 264.748 63.7584 264.078 64.3166C263.408 64.8749 262.18 65.154 260.393 65.154H237.113V109.704C237.113 113.277 237.783 115.733 239.123 117.073C240.575 118.301 242.864 118.916 245.99 118.916C248.111 118.916 250.624 118.804 253.527 118.581C256.43 118.357 258.774 118.134 260.561 117.911C261.677 117.687 262.515 117.799 263.073 118.246C263.631 118.581 263.91 119.418 263.91 120.758L264.245 134.324C264.245 135.552 264.078 136.334 263.743 136.669C263.408 137.115 262.571 137.45 261.231 137.673C257.993 138.232 254.699 138.622 251.349 138.846C248.111 139.181 244.873 139.348 241.635 139.348C237.058 139.348 233.15 138.79 229.912 137.673C226.785 136.669 224.162 134.938 222.04 132.481C219.919 130.025 218.356 126.787 217.351 122.768C216.457 118.636 216.011 113.612 216.011 107.694V65.154H199.933Z" },
  // i in Artist — body only (dot is extracted so it can fly independently)
  { id: "i1_body", dur: 0.9, d: "M283.46 54.1003C283.46 52.3138 283.795 51.0856 284.465 50.4157C285.135 49.6341 286.419 49.2433 288.317 49.2433H299.706C301.604 49.2433 302.888 49.6341 303.558 50.4157C304.228 51.0856 304.563 52.3138 304.563 54.1003V132.984C304.563 134.77 304.228 135.999 303.558 136.669C302.888 137.338 301.604 137.673 299.706 137.673H288.317C286.419 137.673 285.135 137.338 284.465 136.669C283.795 135.999 283.46 134.77 283.46 132.984V54.1003Z" },
  { id: "s1", dur: 1.0, d: "M331.748 114.059C335.879 115.733 340.29 117.185 344.979 118.413C349.669 119.53 354.023 120.088 358.043 120.088C362.732 120.088 366.696 119.418 369.934 118.078C373.284 116.738 374.958 114.505 374.958 111.379C374.958 109.704 374.288 108.253 372.949 107.024C371.609 105.796 369.878 104.68 367.757 103.675C365.635 102.67 363.235 101.721 360.555 100.828C357.875 99.9343 355.14 98.9852 352.348 97.9804C348.775 96.7522 345.203 95.3565 341.63 93.7933C338.168 92.2302 335.042 90.3879 332.251 88.2664C329.571 86.0333 327.338 83.4653 325.551 80.5623C323.877 77.5476 323.039 74.0864 323.039 70.1785C323.039 67.0522 323.653 63.8142 324.882 60.4645C326.221 57.1149 328.399 54.1003 331.413 51.4206C334.54 48.7409 338.559 46.5636 343.472 44.8888C348.496 43.1023 354.693 42.2091 362.062 42.2091C368.762 42.2091 374.4 42.7674 378.978 43.8839C383.556 45.0005 387.854 46.5636 391.874 48.5734C393.102 49.1316 393.884 49.8016 394.219 50.5831C394.665 51.3647 394.833 52.4254 394.721 53.7653L394.051 64.8191C393.94 66.4939 393.549 67.4988 392.879 67.8337C392.321 68.1687 391.26 67.9454 389.697 67.1638C386.459 65.489 382.718 64.0375 378.475 62.8093C374.344 61.4694 369.432 60.7995 363.737 60.7995C358.378 60.7995 353.967 61.5811 350.506 63.1442C347.157 64.7074 345.482 67.108 345.482 70.346C345.482 72.3557 346.319 74.0863 347.994 75.5378C349.669 76.8777 351.846 78.1059 354.526 79.2225C357.205 80.339 360.22 81.4555 363.57 82.5721C366.919 83.577 370.269 84.7493 373.619 86.0892C377.08 87.429 380.206 88.9364 382.997 90.6112C385.901 92.1743 388.413 94.0166 390.534 96.1381C392.656 98.1478 394.275 100.493 395.391 103.172C396.619 105.852 397.233 108.867 397.233 112.216C397.233 120.59 393.884 127.066 387.185 131.644C380.597 136.334 371.72 138.678 360.555 138.678C352.963 138.678 346.654 138.064 341.63 136.836C336.717 135.719 332.027 134.045 327.561 131.812C326.333 131.142 325.607 130.36 325.384 129.467C325.272 128.462 325.328 127.122 325.551 125.447L327.226 116.738C327.45 115.175 328.231 114.282 329.571 114.059Z" },
  // 4-point star — doesn't drop in; bursts open when the flying dot arrives
  { id: "star", dur: 1.0, d: "M452.12 0.545355C456.039 0.545355 456.396 49.5035 463.539 54.3509C471.969 60.0721 490.539 59.0451 490.539 62.1465C490.539 64.5451 472.355 62.87 463.539 67.8331C456.25 71.9364 454.701 131.545 452.12 131.545C449.539 131.545 449.859 72.6209 443.539 67.8331C434.253 60.7989 415.039 63.1289 415.039 60.587C415.039 58.0451 434.651 59.9444 443.539 53.7648C449.253 49.7918 448.039 0.545355 452.12 0.545355Z" },
  // Designer
  { id: "D", dur: 1.1, d: "M458.195 137.045C447 137.544 451.5 109.319 452.672 109.319C457.656 109.319 450.325 126.827 456 129.545C461.675 132.263 471.891 130.038 479.61 127.936C487.853 125.542 495.347 121.876 502.091 116.939C508.835 112.001 514.972 102.414 519.168 94.7828C523.364 87.0023 525.932 75.6438 525.932 64.5717C525.932 54.5468 524.243 43.4196 520.946 36.3872C517.648 29.2053 514.476 24.7484 507.783 18.927C502.056 13.7484 501.248 13.27 491.224 8.42701C485.014 5.42701 479.61 4.52376 469.489 2.02374C459.368 -0.476277 467.561 0.0450508 474.539 0.0453546C481.517 0.0456585 489.137 -0.0673738 495.481 1.76185C501.826 3.59172 507.669 6.15354 513.012 9.44732C518.466 12.6191 523.141 16.7668 527.036 21.8905C531.043 26.8921 534.16 32.9307 536.386 40.0062C538.612 46.9598 539.725 55.0722 539.725 64.3436C539.725 87.4 532.913 107.357 519 120.044C505.198 132.609 487.106 135.757 458.195 137.045Z" },
  { id: "e1", dur: 0.95, d: "M629.829 85.2518C628.936 78.5525 626.423 73.5281 622.292 70.1785C618.273 66.8288 613.192 65.154 607.051 65.154C600.24 65.154 594.658 67.2755 590.303 71.5183C585.949 75.7612 583.548 81.5114 583.102 88.7689C582.655 96.0264 630.722 91.951 629.829 85.2518ZM606.549 46.0612C613.695 46.0612 619.947 47.2336 625.307 49.5783C630.778 51.923 635.411 55.2726 639.208 59.6271C643.004 63.87 645.907 69.0619 647.917 75.2029C650.038 81.3439 651.266 88.2106 651.601 95.8031C651.713 98.0362 651.378 99.5993 650.596 100.493C649.815 101.274 648.363 101.777 646.242 102L584.609 106.857C585.39 110.318 586.842 113.165 588.963 115.398C591.196 117.631 593.82 119.418 596.835 120.758C599.85 121.986 603.143 122.768 606.716 123.103C610.401 123.438 614.03 123.438 617.603 123.103C621.176 122.768 624.637 122.209 627.986 121.428C631.336 120.535 634.239 119.474 636.695 118.246C638.259 117.464 639.319 117.352 639.878 117.911C640.436 118.469 640.827 119.53 641.05 121.093L642.222 132.314C642.446 133.877 642.278 134.938 641.72 135.496C641.273 136.054 640.268 136.613 638.705 137.171C633.904 139.069 628.88 140.409 623.632 141.191C618.384 142.084 613.695 142.53 609.564 142.53C601.971 142.53 595.216 141.302 589.298 138.846C583.492 136.389 578.579 133.04 574.56 128.797C570.54 124.442 567.47 119.306 565.349 113.389C563.339 107.359 562.334 100.828 562.334 93.7933C562.334 87.6524 563.283 81.7347 565.181 76.0403C567.191 70.346 570.038 65.2657 573.723 60.7995C577.519 56.3333 582.152 52.7604 587.623 50.0807C593.095 47.401 599.403 46.0612 606.549 46.0612Z" },
  { id: "s2", dur: 1.0, d: "M672.444 117.911C676.575 119.585 680.985 121.037 685.675 122.265C690.364 123.382 694.719 123.94 698.738 123.94C703.428 123.94 707.391 123.27 710.629 121.93C713.979 120.59 715.654 118.357 715.654 115.231C715.654 113.556 714.984 112.105 713.644 110.876C712.304 109.648 710.573 108.532 708.452 107.527C706.331 106.522 703.93 105.573 701.25 104.68C698.571 103.786 695.835 102.837 693.044 101.832C689.471 100.604 685.898 99.2086 682.325 97.6454C678.864 96.0822 675.737 94.2399 672.946 92.1185C670.266 89.8854 668.033 87.3174 666.247 84.4144C664.572 81.3997 663.735 77.9384 663.735 74.0305C663.735 70.9042 664.349 67.6663 665.577 64.3166C666.917 60.967 669.094 57.9524 672.109 55.2727C675.235 52.593 679.255 50.4157 684.167 48.7409C689.192 46.9544 695.389 46.0612 702.758 46.0612C709.457 46.0612 715.095 46.6194 719.673 47.736C724.251 48.8525 728.55 50.4157 732.569 52.4255C733.798 52.9837 734.579 53.6537 734.914 54.4352C735.361 55.2168 735.528 56.2775 735.417 57.6174L734.747 68.6712C734.635 70.346 734.244 71.3508 733.574 71.6858C733.016 72.0208 731.955 71.7975 730.392 71.0159C727.154 69.3411 723.414 67.8896 719.171 66.6614C715.04 65.3215 710.127 64.6516 704.432 64.6516C699.073 64.6516 694.663 65.4332 691.201 66.9963C687.852 68.5595 686.177 70.96 686.177 74.198C686.177 76.2078 687.014 77.9385 688.689 79.39C690.364 80.7298 692.541 81.958 695.221 83.0745C697.901 84.1911 700.915 85.3076 704.265 86.4241C707.615 87.429 710.964 88.6014 714.314 89.9413C717.775 91.2811 720.902 92.7885 723.693 94.4633C726.596 96.0264 729.108 97.8687 731.229 99.9901C733.351 102 734.97 104.345 736.086 107.024C737.315 109.704 737.929 112.719 737.929 116.068C737.929 124.442 734.579 130.918 727.88 135.496C721.292 140.186 712.416 142.53 701.25 142.53C693.658 142.53 687.349 141.916 682.325 140.688C677.412 139.572 672.723 137.897 668.257 135.664C667.028 134.994 666.303 134.212 666.079 133.319C665.968 132.314 666.023 130.974 666.247 129.299L667.922 120.59C668.145 119.027 668.927 118.134 670.266 117.911H672.444Z" },
  { id: "i2", dur: 0.9, d: "M752.62 25.7959C752.62 21.9997 753.904 18.8176 756.472 16.2495C759.152 13.6815 762.446 12.3974 766.353 12.3974C770.261 12.3974 773.611 13.6815 776.402 16.2495C779.194 18.8176 780.589 21.9997 780.589 25.7959C780.589 29.7038 779.194 32.9418 776.402 35.5099C773.611 37.9663 770.261 39.1944 766.353 39.1944C762.446 39.1944 759.152 37.9663 756.472 35.5099C753.904 32.9418 752.62 29.7038 752.62 25.7959ZM756.472 57.9523C756.472 56.1659 756.807 54.9377 757.477 54.2678C758.147 53.4862 759.431 53.0954 761.329 53.0954H772.718C774.616 53.0954 775.9 53.4862 776.57 54.2678C777.24 54.9377 777.575 56.1659 777.575 57.9523V136.836C777.575 138.622 777.24 139.851 776.57 140.521C775.9 141.191 774.616 141.525 772.718 141.525H761.329C759.431 141.525 758.147 141.191 757.477 140.521C756.807 139.851 756.472 138.622 756.472 136.836V57.9523Z" },
  { id: "g", dur: 1.05, d: "M880.334 136.334C880.445 143.814 879.329 149.955 876.984 154.757C874.751 159.669 871.68 163.577 867.773 166.48C863.865 169.383 859.287 171.393 854.039 172.51C848.791 173.738 843.264 174.352 837.458 174.352C833.885 174.352 830.145 174.184 826.237 173.849C822.441 173.626 818.421 173.235 814.178 172.677C812.504 172.454 811.443 172.007 810.996 171.337C810.55 170.779 810.326 169.774 810.326 168.322L810.661 156.599C810.773 154.812 811.108 153.64 811.666 153.082C812.225 152.635 813.285 152.523 814.848 152.747C817.863 153.305 821.045 153.807 824.395 154.254C827.744 154.701 830.759 154.924 833.439 154.924C837.235 154.924 840.585 154.757 843.488 154.422C846.502 154.087 849.07 153.361 851.192 152.244C853.313 151.239 854.988 149.732 856.216 147.722C857.445 145.713 858.282 143.089 858.729 139.851C850.466 140.074 842.483 139.516 834.779 138.176C827.075 136.948 820.208 134.603 814.178 131.142C808.261 127.68 803.46 122.935 799.775 116.906C796.202 110.765 794.416 102.949 794.416 93.4584C794.416 85.4193 796.146 78.4409 799.608 72.5232C803.069 66.4939 807.703 61.4694 813.509 57.4499C819.426 53.4303 826.293 50.4157 834.109 48.4059C841.925 46.3961 850.187 45.3912 858.896 45.3912H872.797C875.253 45.3912 876.984 45.9495 877.989 47.066C878.994 48.1826 879.496 50.2482 879.496 53.2629L880.334 136.334ZM816.188 94.9657C816.188 104.568 819.705 111.267 826.74 115.063C833.885 118.748 839.915 120.871 854.542 120.648C869.168 120.425 868.889 64.8208 854.039 65.0441C839.189 65.2674 833.216 67.6104 826.405 72.8582C819.594 78.1059 816.188 85.4751 816.188 94.9657Z" },
  { id: "n", dur: 1.0, d: "M984.924 136.836C984.924 138.622 984.589 139.851 983.919 140.521C983.249 141.191 981.965 141.525 980.067 141.525H968.679C966.781 141.525 965.444 141.191 964.662 140.521C963.992 139.851 963.713 138.622 963.825 136.836L965.165 89.2713C965.388 80.2274 963.658 74.0864 959.974 70.8484C956.401 67.6104 950.483 66.3264 942.221 66.9963C938.648 67.2197 935.019 67.4988 931.334 67.8337C927.65 68.1687 924.356 68.6711 921.453 69.3411V136.836C921.453 138.622 921.118 139.851 920.448 140.521C919.778 141.191 918.494 141.525 916.596 141.525H905.207C903.309 141.525 902.025 141.191 901.355 140.521C900.685 139.851 900.35 138.622 900.35 136.836L899.01 58.4548C899.01 56.8916 899.066 55.6634 899.178 54.7702C899.29 53.7653 899.513 52.9837 899.848 52.4255C900.294 51.8672 900.964 51.4764 901.858 51.2531C902.751 50.9181 903.923 50.639 905.375 50.4157C908.389 49.9691 911.46 49.5225 914.586 49.0758C917.712 48.6292 921.118 48.2942 924.802 48.0709C928.487 47.736 932.562 47.5127 937.029 47.401C941.606 47.1777 946.854 47.066 952.772 47.066C958.801 47.066 963.933 48.1268 968.176 50.2482C972.531 52.3696 976.048 55.2726 978.727 58.9572C981.519 62.6418 983.529 66.9963 984.757 72.0208C985.985 77.0452 986.487 82.4046 986.264 88.099L984.924 136.836Z" },
  { id: "e2", dur: 0.95, d: "M1044.68 47.5685C1058.3 47.5685 1068.8 51.9788 1076.17 60.7995C1083.65 69.6202 1087.72 81.8463 1088.39 97.4779C1088.5 99.711 1088.17 101.218 1087.39 102C1086.72 102.781 1085.38 103.284 1083.37 103.507L1030.11 107.694C1031.23 111.156 1033.46 113.668 1036.81 115.231C1040.16 116.794 1043.95 117.631 1048.2 117.743C1052.44 117.966 1056.85 117.631 1061.43 116.738C1066.01 115.733 1070.08 114.394 1073.65 112.719C1076.56 111.379 1078.06 112.328 1078.18 115.566L1079.18 130.807C1079.29 132.147 1079.07 133.207 1078.51 133.989C1078.06 134.77 1077.06 135.44 1075.5 135.999C1070.92 137.673 1066.06 138.902 1060.93 139.683C1055.9 140.576 1051.43 141.023 1047.53 141.023C1040.38 141.023 1033.96 139.851 1028.27 137.506C1022.68 135.273 1017.94 132.035 1014.03 127.792C1010.01 123.661 1006.94 118.692 1004.82 112.886C1002.81 107.08 1001.8 100.716 1001.8 93.7933C1001.8 87.764 1002.75 81.958 1004.65 76.3753C1006.55 70.7926 1009.34 65.8239 1013.03 61.4694C1016.71 57.2266 1021.18 53.877 1026.42 51.4206C1031.78 48.8525 1037.87 47.5685 1044.68 47.5685ZM1061.26 83.4095C1060.03 79.2783 1058.19 76.152 1055.73 74.0305C1053.39 71.7974 1049.98 70.6809 1045.52 70.6809C1040.83 70.6809 1036.98 72.1883 1033.96 75.2029C1030.95 78.2176 1029.16 81.8463 1028.6 86.0892C1028.04 90.332 1062.49 87.5407 1061.26 83.4095Z" },
  { id: "r2", dur: 1.0, d: "M1103.94 58.2873C1103.94 56.6125 1104 55.2727 1104.11 54.2678C1104.22 53.1512 1104.5 52.3138 1104.95 51.7555C1105.51 51.1973 1106.23 50.7507 1107.12 50.4157C1108.02 50.0807 1109.19 49.8016 1110.64 49.5783C1114.77 49.02 1119.41 48.5175 1124.54 48.0709C1129.79 47.6243 1134.98 47.3452 1140.12 47.2335C1145.25 47.0102 1150.06 46.8986 1154.52 46.8986C1159.1 46.8986 1162.73 47.0661 1165.41 47.401C1167.31 47.6243 1168.48 48.0151 1168.92 48.5734C1169.37 49.02 1169.54 50.1924 1169.43 52.0905L1168.92 61.4694C1168.81 63.8142 1168.48 65.2657 1167.92 65.824C1167.36 66.2706 1165.85 66.438 1163.4 66.3264C1161.72 66.3264 1159.27 66.3822 1156.03 66.4939C1152.79 66.6055 1149.33 66.773 1145.64 66.9963C1142.07 67.108 1138.5 67.3313 1134.93 67.6663C1131.35 67.8896 1128.39 68.1687 1126.05 68.5037L1126.38 136.836C1126.38 138.622 1126.05 139.851 1125.38 140.521C1124.71 141.191 1123.43 141.525 1121.53 141.525H1110.14C1108.24 141.525 1106.96 141.191 1106.29 140.521C1105.62 139.851 1105.28 138.622 1105.28 136.836L1103.94 58.2873Z" },
];

// Extracted i-dot from the Artist's i body — this is the dot that flies.
const I_DOT_D = "M279.608 21.9439C279.608 18.1476 280.892 14.9655 283.46 12.3974C286.14 9.82939 289.434 8.54535 293.341 8.54535C297.249 8.54535 300.599 9.82939 303.39 12.3974C306.182 14.9655 307.577 18.1476 307.577 21.9439C307.577 25.8517 306.182 29.0897 303.39 31.6578C300.599 34.1142 297.249 35.3424 293.341 35.3424C289.434 35.3424 286.14 34.1142 283.46 31.6578C280.892 29.0897 279.608 25.8517 279.608 21.9439Z";

// Anchor points: i-dot natural center → star center → middot center.
const I_DOT_CENTER = { x: 293.5, y: 21.94 };
const STAR_CENTER = { x: 452.5, y: 66 };
const MIDDOT_CENTER = { x: 504, y: 63 };

// Horizontal/vertical deltas the i-dot needs to travel to reach the star.
const DX = STAR_CENTER.x - I_DOT_CENTER.x;
const DY = STAR_CENTER.y - I_DOT_CENTER.y;

// Translations measured from the i-dot's natural position: where the ejected
// dot starts (at the star) and where it ends (at the middot).
const EJECT_SX = STAR_CENTER.x - I_DOT_CENTER.x;
const EJECT_SY = STAR_CENTER.y - I_DOT_CENTER.y;
const EJECT_MX = MIDDOT_CENTER.x - I_DOT_CENTER.x;
const EJECT_MY = MIDDOT_CENTER.y - I_DOT_CENTER.y;
// Final scale of the ejected dot — shrinks down to middot size.
const MIDDOT_SCALE = 0.36;

// Timing constants — ported from main.jsx DEFAULTS
const LETTER_DUR = 400;
const LETTER_STAGGER = 20;
const SHOOT_DUR = 500;

// glyph order MUST match the GLYPHS array order above
const GLYPH_ORDER = ["A", "r", "t", "i1_body", "s1", "star", "D", "e1", "s2", "i2", "g", "n", "e2", "r2"] as const;

function computeTimings() {
  // Drop sequence — letters fall in left-to-right order. The 4-point star
  // does NOT drop in; it bursts open at the moment the flying i-dot lands
  // on it. The i-dot drops alongside the i body and is then knocked loose
  // when the i bounces on impact.
  const dropOrder = ["A", "r", "t", "i1_body", "s1", "D", "e1", "s2", "i2", "g", "n", "e2", "r2"];
  const base = 80;
  const letterDelays: Record<string, number> = {};
  dropOrder.forEach((id, idx) => {
    letterDelays[id] = base + idx * LETTER_STAGGER;
  });

  // The dot drops with the i body. The launch (knockOff) fires at ~86% of
  // the drop duration so it is synced to the visible squash on impact.
  const dotDropAt = letterDelays.i1_body;
  const shootStart = letterDelays.i1_body + Math.round(LETTER_DUR * 0.86);
  // Star bursts a hair before the dot finishes its arc, so the burst feels
  // caused by the dot rather than chasing it.
  const starBurstAt = shootStart + SHOOT_DUR - 40;
  // A fresh dot is ejected from the star once the burst has opened — lands
  // between the star and the D as the middot punctuation.
  const ejectAt = starBurstAt + 240;
  const ejectDur = 120;
  // New replacement dot pops onto the i after the original has cleared.
  const newDotAt = shootStart + 220;

  // Star is keyed off starBurstAt, not the cascade. Slot it in here so the
  // GLYPHS map can look it up by id.
  letterDelays.star = starBurstAt;

  const letterDelaysArr = GLYPH_ORDER.map((id) => letterDelays[id]);
  return {
    letterDur: LETTER_DUR,
    letterDelays: letterDelaysArr,
    dotDropAt,
    shootStart,
    shootDur: SHOOT_DUR,
    starBurstAt,
    ejectAt,
    ejectDur,
    newDotAt,
  };
}

export default function ArtistDesignerWordmark() {
  // a single mount-time runKey so the animation plays once and stays at the end
  const [runKey] = useState(1);
  const t = useMemo(() => computeTimings(), []);

  // honor reduced motion: skip the animation, render the final mark statically
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  if (reduced) {
    // Static version: full word, no animation
    return (
      <svg
        className="wordmark"
        viewBox="0 0 1170 175"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid meet"
        overflow="visible"
        style={{ overflow: "visible" }}
        role="img"
        aria-label="Artist × Designer"
      >
        <title>Artist × Designer</title>
        {GLYPHS.map((g) => (
          <path key={g.id} d={g.d} fill="var(--hero-fg)" />
        ))}
        <path d={I_DOT_D} fill="var(--hero-fg)" />
        {/* the middot */}
        <ellipse cx={MIDDOT_CENTER.x} cy={MIDDOT_CENTER.y} rx="5" ry="4" fill="var(--hero-fg)" />
      </svg>
    );
  }

  return (
    <svg
      key={runKey}
      className="wordmark"
      viewBox="0 0 1170 175"
      xmlns="http://www.w3.org/2000/svg"
      preserveAspectRatio="xMidYMid meet"
      overflow="visible"
      style={{ overflow: "visible" }}
      role="img"
      aria-label="Artist × Designer"
    >
      <title>Artist × Designer</title>
      {/* glyphs — each letter drops in from above with a bounce.
          The 4-point star is special: it bursts open at the moment the
          flying dot lands on it (no drop-in). */}
      {GLYPHS.map((g, i) => {
        const dur = Math.round(t.letterDur * g.dur);
        const delay = t.letterDelays[i];
        if (g.id === "star") {
          return (
            <path
              key={g.id}
              d={g.d}
              fill="var(--hero-fg)"
              style={{
                transformBox: "fill-box",
                transformOrigin: "50% 50%",
                transform: "scale(0) rotate(-40deg)",
                opacity: 0,
                animation: `burstStar 620ms cubic-bezier(0.34, 1.75, 0.5, 1) ${t.starBurstAt}ms forwards`,
              }}
            />
          );
        }
        return (
          <path
            key={g.id}
            d={g.d}
            fill="var(--hero-fg)"
            style={{
              transformBox: "fill-box",
              transformOrigin: "50% 100%",
              transform: "translateY(-260px)",
              opacity: 0,
              animation: `dropIn ${dur}ms cubic-bezier(0.34, 1.56, 0.5, 1) ${delay}ms forwards`,
            }}
          />
        );
      })}

      {/* the original i-dot — drops in WITH the i body, then on the i's
          bounce settle, gets knocked loose and arcs up + over toward the
          star. Lands on the star center and pops out of existence (the
          star itself bursts in at the same moment, visually absorbing it). */}
      <path
        className="flying-dot"
        d={I_DOT_D}
        fill="var(--hero-fg)"
        style={{
          transformBox: "fill-box",
          transformOrigin: "50% 50%",
          transform: "translateY(-260px)",
          opacity: 0,
          animation:
            `dropIn ${Math.round(t.letterDur * 0.9)}ms cubic-bezier(0.34, 1.56, 0.5, 1) ${t.dotDropAt}ms forwards,` +
            `knockOff ${t.shootDur}ms cubic-bezier(0.30, 0.05, 0.45, 1) ${t.shootStart}ms forwards`,
        }}
      />

      {/* a SECOND dot is ejected from the star once it has burst open —
          a tiny aftershock that bounces over and settles as the middot
          between the star and the D's arc. */}
      <path
        className="ejected-dot"
        d={I_DOT_D}
        fill="var(--hero-fg)"
        style={{
          transformBox: "fill-box",
          transformOrigin: "50% 50%",
          transform: `translate(${EJECT_SX}px, ${EJECT_SY}px) scale(0)`,
          opacity: 0,
          animation: `ejectDot ${t.ejectDur}ms cubic-bezier(0.34, 1.5, 0.45, 1) ${t.ejectAt}ms forwards`,
        }}
      />

      {/* a NEW dot grows back onto the i shortly after the first one
          launches — keeps the i lowercase-looking once the dust settles. */}
      <path
        className="new-i-dot"
        d={I_DOT_D}
        fill="var(--hero-fg)"
        style={{
          transformBox: "fill-box",
          transformOrigin: "50% 50%",
          transform: "scale(0)",
          opacity: 0,
          animation: `popDot 380ms cubic-bezier(0.34, 1.56, 0.64, 1) ${t.newDotAt}ms forwards`,
        }}
      />

      <style>{`
        /* dropIn: letter falls from above, slight overshoot then settles.
           transformOrigin is the baseline (50% 100%) so the squash on
           landing reads as weight planting onto the line. */
        @keyframes dropIn {
          0%   { transform: translateY(-260px) scaleY(1); opacity: 0; }
          40%  { opacity: 1; }
          70%  { transform: translateY(6px) scaleY(0.92); opacity: 1; }
          84%  { transform: translateY(-3px) scaleY(1.02); opacity: 1; }
          100% { transform: translateY(0) scaleY(1); opacity: 1; }
        }
        /* knockOff: dot is launched up + sideways on the i's bounce.
           It peaks high and arcs over into the star's position, where
           it shrinks to nothing as the star bursts open. */
        @keyframes knockOff {
          0%   { transform: translate(0px, 0px) scale(1); opacity: 1; }
          18%  { transform: translate(${DX * 0.12}px, -76px) scale(1.05); opacity: 1; }
          45%  { transform: translate(${DX * 0.45}px, -96px) scale(1.02); opacity: 1; }
          75%  { transform: translate(${DX * 0.80}px, -54px) scale(0.95); opacity: 1; }
          95%  { transform: translate(${DX * 0.98}px, ${DY - 4}px) scale(0.55); opacity: 1; }
          100% { transform: translate(${DX}px, ${DY}px) scale(0.1); opacity: 0; }
        }
        /* burstStar: 4-point star explodes outward from the dot's landing
           point. Big overshoot, then settles with a tiny back-rotation. */
        @keyframes burstStar {
          0%   { transform: scale(0) rotate(-40deg); opacity: 0; }
          30%  { opacity: 1; }
          55%  { transform: scale(1.8) rotate(18deg); opacity: 1; }
          75%  { transform: scale(0.86) rotate(-6deg); opacity: 1; }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        /* popDot: replacement dot ink-presses onto the i after launch. */
        @keyframes popDot {
          0%   { transform: scale(0); opacity: 0; }
          60%  { transform: scale(1.18); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
        /* ejectDot: a fresh dot is launched out of the star at the moment
           of the burst, scales up mid-flight, arcs over to the middot
           position, then squashes flat on impact and settles into the
           small middot between Artist and Designer. */
        @keyframes ejectDot {
          0%   { transform: translate(${EJECT_SX}px, ${EJECT_SY}px) scale(0);                                opacity: 0; }
          15%  { transform: translate(${EJECT_SX}px, ${EJECT_SY - 10}px) scale(0.55);                        opacity: 1; }
          50%  { transform: translate(${EJECT_SX + (EJECT_MX - EJECT_SX) * 0.50}px, ${EJECT_SY - 34}px) scale(0.48); opacity: 1; }
          78%  { transform: translate(${EJECT_SX + (EJECT_MX - EJECT_SX) * 0.86}px, ${EJECT_SY - 14}px) scale(0.44); opacity: 1; }
          90%  { transform: translate(${EJECT_MX}px, ${EJECT_MY + 4}px) scaleX(${MIDDOT_SCALE * 1.35}) scaleY(${MIDDOT_SCALE * 0.55}); opacity: 1; }
          100% { transform: translate(${EJECT_MX}px, ${EJECT_MY}px) scale(${MIDDOT_SCALE});                  opacity: 1; }
        }
      `}</style>
    </svg>
  );
}
